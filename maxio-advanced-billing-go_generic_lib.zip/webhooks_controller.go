// Package advancedbilling
// This file was automatically generated for Maxio by APIMATIC v3.0 ( https://www.apimatic.io ).
package advancedbilling

import (
    "context"
    "github.com/apimatic/go-core-runtime/https"
    "github.com/apimatic/go-core-runtime/utilities"
    "github.com/maxio-com/ab-golang-sdk/errors"
    "github.com/maxio-com/ab-golang-sdk/models"
)

// WebhooksController represents a controller struct.
type WebhooksController struct {
    baseController
}

// NewWebhooksController creates a new instance of WebhooksController.
// It takes a baseController as a parameter and returns a pointer to the WebhooksController.
func NewWebhooksController(baseController baseController) *WebhooksController {
    webhooksController := WebhooksController{baseController: baseController}
    return &webhooksController
}

// ListWebhooksInput represents the input of the ListWebhooks endpoint.
type ListWebhooksInput struct {
    // Webhooks with matching status would be returned.
    Status       *models.WebhookStatus 
    // Format YYYY-MM-DD. Returns Webhooks with the created_at date greater than or equal to the one specified.
    SinceDate    *string               
    // Format YYYY-MM-DD. Returns Webhooks with the created_at date less than or equal to the one specified.
    UntilDate    *string               
    // Result records are organized in pages. By default, the first page of results is displayed. The page parameter specifies a page number of results to fetch. You can start navigating through the pages to consume the results. You do this by passing in a page parameter. Retrieve the next page by adding ?page=2 to the query string. If there are no results to return, then an empty result set will be returned.
    // Use in query `page=1`.
    Page         *int                  
    // This parameter indicates how many records to fetch in each request. Default value is 20. The maximum allowed values is 200; any per_page value over 200 will be changed to 200.
    // Use in query `per_page=200`.
    PerPage      *int                  
    // The order in which the Webhooks are returned.
    Order        *models.WebhookOrder  
    // The Advanced Billing id of a subscription you'd like to filter for
    Subscription *int                  
}

// ListWebhooks takes context, status, sinceDate, untilDate, page, perPage, order, subscription as parameters and
// returns an models.ApiResponse with []models.WebhookResponse data and
// an error if there was an issue with the request or response.
// Allows you to view a list of webhooks.  You can pass query parameters if you want to filter webhooks. See the [Webhooks](page:introduction/webhooks/webhooks) documentation for more information.
func (w *WebhooksController) ListWebhooks(
    ctx context.Context,
    input ListWebhooksInput) (
    models.ApiResponse[[]models.WebhookResponse],
    error) {
    req := w.prepareRequest(ctx, "GET", "/webhooks.json")
    
    req.Authenticate(NewAuth("BasicAuth"))
    if input.Status != nil {
        req.QueryParam("status", *input.Status)
    }
    if input.SinceDate != nil {
        req.QueryParam("since_date", *input.SinceDate)
    }
    if input.UntilDate != nil {
        req.QueryParam("until_date", *input.UntilDate)
    }
    if input.Page != nil {
        req.QueryParam("page", *input.Page)
    }
    if input.PerPage != nil {
        req.QueryParam("per_page", *input.PerPage)
    }
    if input.Order != nil {
        req.QueryParam("order", *input.Order)
    }
    if input.Subscription != nil {
        req.QueryParam("subscription", *input.Subscription)
    }
    var result []models.WebhookResponse
    decoder, resp, err := req.CallAsJson()
    if err != nil {
        return models.NewApiResponse(result, resp), err
    }
    
    result, err = utilities.DecodeResults[[]models.WebhookResponse](decoder)
    return models.NewApiResponse(result, resp), err
}

// EnableWebhooks takes context, body as parameters and
// returns an models.ApiResponse with models.EnableWebhooksResponse data and
// an error if there was an issue with the request or response.
// Allows you to enable webhooks for your site
func (w *WebhooksController) EnableWebhooks(
    ctx context.Context,
    body *models.EnableWebhooksRequest) (
    models.ApiResponse[models.EnableWebhooksResponse],
    error) {
    req := w.prepareRequest(ctx, "PUT", "/webhooks/settings.json")
    
    req.Authenticate(NewAuth("BasicAuth"))
    req.Header("Content-Type", "application/json")
    if body != nil {
        req.Json(body)
    }
    var result models.EnableWebhooksResponse
    decoder, resp, err := req.CallAsJson()
    if err != nil {
        return models.NewApiResponse(result, resp), err
    }
    
    result, err = utilities.DecodeResults[models.EnableWebhooksResponse](decoder)
    return models.NewApiResponse(result, resp), err
}

// ReplayWebhooks takes context, body as parameters and
// returns an models.ApiResponse with models.ReplayWebhooksResponse data and
// an error if there was an issue with the request or response.
// Replays webhooks. Posting to this endpoint does not immediately resend the webhooks. They are added to a queue and sent as soon as possible, depending on available system resources. You can submit an array of up to 1000 webhook IDs in the replay request.
func (w *WebhooksController) ReplayWebhooks(
    ctx context.Context,
    body *models.ReplayWebhooksRequest) (
    models.ApiResponse[models.ReplayWebhooksResponse],
    error) {
    req := w.prepareRequest(ctx, "POST", "/webhooks/replay.json")
    
    req.Authenticate(NewAuth("BasicAuth"))
    req.Header("Content-Type", "application/json")
    if body != nil {
        req.Json(body)
    }
    var result models.ReplayWebhooksResponse
    decoder, resp, err := req.CallAsJson()
    if err != nil {
        return models.NewApiResponse(result, resp), err
    }
    
    result, err = utilities.DecodeResults[models.ReplayWebhooksResponse](decoder)
    return models.NewApiResponse(result, resp), err
}

// CreateEndpoint takes context, body as parameters and
// returns an models.ApiResponse with models.EndpointResponse data and
// an error if there was an issue with the request or response.
// Creates an endpoint and assigns a list of webhooks subscriptions (events) to it.
// See the [Webhooks Reference](page:introduction/webhooks/webhooks-reference#events) page for available events.
func (w *WebhooksController) CreateEndpoint(
    ctx context.Context,
    body *models.CreateOrUpdateEndpointRequest) (
    models.ApiResponse[models.EndpointResponse],
    error) {
    req := w.prepareRequest(ctx, "POST", "/endpoints.json")
    
    req.Authenticate(NewAuth("BasicAuth"))
    req.AppendErrors(map[string]https.ErrorBuilder[error]{
        "422": {TemplatedMessage: "HTTP Response Not OK. Status code: {$statusCode}. Response: '{$response.body}'.", Unmarshaller: errors.NewErrorListResponse},
    })
    req.Header("Content-Type", "application/json")
    if body != nil {
        req.Json(body)
    }
    var result models.EndpointResponse
    decoder, resp, err := req.CallAsJson()
    if err != nil {
        return models.NewApiResponse(result, resp), err
    }
    
    result, err = utilities.DecodeResults[models.EndpointResponse](decoder)
    return models.NewApiResponse(result, resp), err
}

// ListEndpoints takes context as parameters and
// returns an models.ApiResponse with []models.Endpoint data and
// an error if there was an issue with the request or response.
// Returns created endpoints for a site.
func (w *WebhooksController) ListEndpoints(ctx context.Context) (
    models.ApiResponse[[]models.Endpoint],
    error) {
    req := w.prepareRequest(ctx, "GET", "/endpoints.json")
    
    req.Authenticate(NewAuth("BasicAuth"))
    var result []models.Endpoint
    decoder, resp, err := req.CallAsJson()
    if err != nil {
        return models.NewApiResponse(result, resp), err
    }
    
    result, err = utilities.DecodeResults[[]models.Endpoint](decoder)
    return models.NewApiResponse(result, resp), err
}

// UpdateEndpoint takes context, endpointId, body as parameters and
// returns an models.ApiResponse with models.EndpointResponse data and
// an error if there was an issue with the request or response.
// Updates an Endpoint. You can change the `url` of your endpoint or the list of `webhook_subscriptions` to which you are subscribed. See the [Webhooks Reference](page:introduction/webhooks/webhooks-reference#events) page for available events.
// Always send a complete list of events to which you want to subscribe. Sending a PUT request for an existing endpoint with an empty list of `webhook_subscriptions` will unsubscribe all events.
// If you want unsubscribe from a specific event, send a list of `webhook_subscriptions` without the specific event key.
func (w *WebhooksController) UpdateEndpoint(
    ctx context.Context,
    endpointId int,
    body *models.CreateOrUpdateEndpointRequest) (
    models.ApiResponse[models.EndpointResponse],
    error) {
    req := w.prepareRequest(ctx, "PUT", "/endpoints/%v.json")
    req.AppendTemplateParams(endpointId)
    req.Authenticate(NewAuth("BasicAuth"))
    req.AppendErrors(map[string]https.ErrorBuilder[error]{
        "404": {TemplatedMessage: "Not Found:'{$response.body}'"},
        "422": {TemplatedMessage: "HTTP Response Not OK. Status code: {$statusCode}. Response: '{$response.body}'.", Unmarshaller: errors.NewErrorListResponse},
    })
    req.Header("Content-Type", "application/json")
    if body != nil {
        req.Json(body)
    }
    
    var result models.EndpointResponse
    decoder, resp, err := req.CallAsJson()
    if err != nil {
        return models.NewApiResponse(result, resp), err
    }
    
    result, err = utilities.DecodeResults[models.EndpointResponse](decoder)
    return models.NewApiResponse(result, resp), err
}
