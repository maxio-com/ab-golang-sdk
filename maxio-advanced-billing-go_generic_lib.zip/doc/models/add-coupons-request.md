
# Add Coupons Request

## Structure

`AddCouponsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Codes` | `[]string` | Optional | - |

## Example (as JSON)

```json
{
  "codes": [
    "codes0",
    "codes1"
  ]
}
```

