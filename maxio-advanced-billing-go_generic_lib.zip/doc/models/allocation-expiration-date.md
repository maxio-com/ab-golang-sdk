
# Allocation Expiration Date

## Structure

`AllocationExpirationDate`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ExpiresAt` | `*string` | Optional | - |

## Example (as JSON)

```json
{
  "expires_at": "expires_at0"
}
```

