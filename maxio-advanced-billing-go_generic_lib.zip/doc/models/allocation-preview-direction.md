
# Allocation Preview Direction

## Enumeration

`AllocationPreviewDirection`

## Fields

| Name |
|  --- |
| `UPGRADE` |
| `DOWNGRADE` |

