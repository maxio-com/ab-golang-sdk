
# Account Balance

## Structure

`AccountBalance`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BalanceInCents` | `*int64` | Optional | The balance in cents. |

## Example (as JSON)

```json
{
  "balance_in_cents": 16
}
```

