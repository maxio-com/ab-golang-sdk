// Package advancedbilling
// This file was automatically generated for Maxio by APIMATIC v3.0 ( https://www.apimatic.io ).
package advancedbilling

import (
    "context"
    "github.com/apimatic/go-core-runtime/https"
    "github.com/apimatic/go-core-runtime/utilities"
    "github.com/maxio-com/ab-golang-sdk/errors"
    "github.com/maxio-com/ab-golang-sdk/models"
)

// ReasonCodesController represents a controller struct.
type ReasonCodesController struct {
    baseController
}

// NewReasonCodesController creates a new instance of ReasonCodesController.
// It takes a baseController as a parameter and returns a pointer to the ReasonCodesController.
func NewReasonCodesController(baseController baseController) *ReasonCodesController {
    reasonCodesController := ReasonCodesController{baseController: baseController}
    return &reasonCodesController
}

// CreateReasonCode takes context, body as parameters and
// returns an models.ApiResponse with models.ReasonCodeResponse data and
// an error if there was an issue with the request or response.
// Creates a reason code for a given site.
// Reason Codes are a way to gain a high-level view of why your customers are cancelling the subscription to your product or service.
// Add a set of churn reason codes to be displayed in-app and/or the Maxio Billing Portal. As your subscribers decide to cancel their subscription, learn why they decided to cancel.
// For more information, see [Churn Reason Codes](https://maxio.zendesk.com/hc/en-us/articles/24286647554701-Churn-Reason-Codes).
func (r *ReasonCodesController) CreateReasonCode(
    ctx context.Context,
    body *models.CreateReasonCodeRequest) (
    models.ApiResponse[models.ReasonCodeResponse],
    error) {
    req := r.prepareRequest(ctx, "POST", "/reason_codes.json")
    
    req.Authenticate(NewAuth("BasicAuth"))
    req.AppendErrors(map[string]https.ErrorBuilder[error]{
        "422": {TemplatedMessage: "HTTP Response Not OK. Status code: {$statusCode}. Response: '{$response.body}'.", Unmarshaller: errors.NewErrorListResponse},
    })
    req.Header("Content-Type", "application/json")
    if body != nil {
        req.Json(body)
    }
    var result models.ReasonCodeResponse
    decoder, resp, err := req.CallAsJson()
    if err != nil {
        return models.NewApiResponse(result, resp), err
    }
    
    result, err = utilities.DecodeResults[models.ReasonCodeResponse](decoder)
    return models.NewApiResponse(result, resp), err
}

// ListReasonCodesInput represents the input of the ListReasonCodes endpoint.
type ListReasonCodesInput struct {
    // Result records are organized in pages. By default, the first page of results is displayed. The page parameter specifies a page number of results to fetch. You can start navigating through the pages to consume the results. You do this by passing in a page parameter. Retrieve the next page by adding ?page=2 to the query string. If there are no results to return, then an empty result set will be returned.
    // Use in query `page=1`.
    Page    *int 
    // This parameter indicates how many records to fetch in each request. Default value is 20. The maximum allowed values is 200; any per_page value over 200 will be changed to 200.
    // Use in query `per_page=200`.
    PerPage *int 
}

// ListReasonCodes takes context, page, perPage as parameters and
// returns an models.ApiResponse with []models.ReasonCodeResponse data and
// an error if there was an issue with the request or response.
// Lists all current churn codes for a given site.
func (r *ReasonCodesController) ListReasonCodes(
    ctx context.Context,
    input ListReasonCodesInput) (
    models.ApiResponse[[]models.ReasonCodeResponse],
    error) {
    req := r.prepareRequest(ctx, "GET", "/reason_codes.json")
    
    req.Authenticate(NewAuth("BasicAuth"))
    req.AppendErrors(map[string]https.ErrorBuilder[error]{
        "422": {TemplatedMessage: "HTTP Response Not OK. Status code: {$statusCode}. Response: '{$response.body}'.", Unmarshaller: errors.NewErrorListResponse},
    })
    if input.Page != nil {
        req.QueryParam("page", *input.Page)
    }
    if input.PerPage != nil {
        req.QueryParam("per_page", *input.PerPage)
    }
    var result []models.ReasonCodeResponse
    decoder, resp, err := req.CallAsJson()
    if err != nil {
        return models.NewApiResponse(result, resp), err
    }
    
    result, err = utilities.DecodeResults[[]models.ReasonCodeResponse](decoder)
    return models.NewApiResponse(result, resp), err
}

// ReadReasonCode takes context, reasonCodeId as parameters and
// returns an models.ApiResponse with models.ReasonCodeResponse data and
// an error if there was an issue with the request or response.
// Returns a particular churn reason code for a given site by its unique ID.
func (r *ReasonCodesController) ReadReasonCode(
    ctx context.Context,
    reasonCodeId int) (
    models.ApiResponse[models.ReasonCodeResponse],
    error) {
    req := r.prepareRequest(ctx, "GET", "/reason_codes/%v.json")
    req.AppendTemplateParams(reasonCodeId)
    req.Authenticate(NewAuth("BasicAuth"))
    req.AppendErrors(map[string]https.ErrorBuilder[error]{
        "404": {TemplatedMessage: "Not Found:'{$response.body}'"},
    })
    
    var result models.ReasonCodeResponse
    decoder, resp, err := req.CallAsJson()
    if err != nil {
        return models.NewApiResponse(result, resp), err
    }
    
    result, err = utilities.DecodeResults[models.ReasonCodeResponse](decoder)
    return models.NewApiResponse(result, resp), err
}

// UpdateReasonCode takes context, reasonCodeId, body as parameters and
// returns an models.ApiResponse with models.ReasonCodeResponse data and
// an error if there was an issue with the request or response.
// Updates an existing reason code for a given site.
func (r *ReasonCodesController) UpdateReasonCode(
    ctx context.Context,
    reasonCodeId int,
    body *models.UpdateReasonCodeRequest) (
    models.ApiResponse[models.ReasonCodeResponse],
    error) {
    req := r.prepareRequest(ctx, "PUT", "/reason_codes/%v.json")
    req.AppendTemplateParams(reasonCodeId)
    req.Authenticate(NewAuth("BasicAuth"))
    req.AppendErrors(map[string]https.ErrorBuilder[error]{
        "404": {TemplatedMessage: "Not Found:'{$response.body}'"},
        "422": {TemplatedMessage: "HTTP Response Not OK. Status code: {$statusCode}. Response: '{$response.body}'.", Unmarshaller: errors.NewErrorListResponse},
    })
    req.Header("Content-Type", "application/json")
    if body != nil {
        req.Json(body)
    }
    
    var result models.ReasonCodeResponse
    decoder, resp, err := req.CallAsJson()
    if err != nil {
        return models.NewApiResponse(result, resp), err
    }
    
    result, err = utilities.DecodeResults[models.ReasonCodeResponse](decoder)
    return models.NewApiResponse(result, resp), err
}

// DeleteReasonCode takes context, reasonCodeId as parameters and
// returns an models.ApiResponse with models.OkResponse data and
// an error if there was an issue with the request or response.
// Deletes a reason code from the Churn Reason Codes. This code will be immediately removed. This action is not reversible.
func (r *ReasonCodesController) DeleteReasonCode(
    ctx context.Context,
    reasonCodeId int) (
    models.ApiResponse[models.OkResponse],
    error) {
    req := r.prepareRequest(ctx, "DELETE", "/reason_codes/%v.json")
    req.AppendTemplateParams(reasonCodeId)
    req.Authenticate(NewAuth("BasicAuth"))
    req.AppendErrors(map[string]https.ErrorBuilder[error]{
        "404": {TemplatedMessage: "Not Found:'{$response.body}'"},
    })
    
    var result models.OkResponse
    decoder, resp, err := req.CallAsJson()
    if err != nil {
        return models.NewApiResponse(result, resp), err
    }
    
    result, err = utilities.DecodeResults[models.OkResponse](decoder)
    return models.NewApiResponse(result, resp), err
}
