/*
Package advancedbilling

This file was automatically generated for Maxio by APIMATIC v3.0 ( https://www.apimatic.io ).
*/
package models

import (
    "encoding/json"
    "errors"
    "strings"
)

// BankAccountResponse represents a BankAccountResponse struct.
type BankAccountResponse struct {
    PaymentProfile       BankAccountPaymentProfile `json:"payment_profile"`
    AdditionalProperties map[string]any            `json:"_"`
}

// MarshalJSON implements the json.Marshaler interface for BankAccountResponse.
// It customizes the JSON marshaling process for BankAccountResponse objects.
func (b BankAccountResponse) MarshalJSON() (
    []byte,
    error) {
    return json.Marshal(b.toMap())
}

// toMap converts the BankAccountResponse object to a map representation for JSON marshaling.
func (b BankAccountResponse) toMap() map[string]any {
    structMap := make(map[string]any)
    MapAdditionalProperties(structMap, b.AdditionalProperties)
    structMap["payment_profile"] = b.PaymentProfile.toMap()
    return structMap
}

// UnmarshalJSON implements the json.Unmarshaler interface for BankAccountResponse.
// It customizes the JSON unmarshaling process for BankAccountResponse objects.
func (b *BankAccountResponse) UnmarshalJSON(input []byte) error {
    var temp tempBankAccountResponse
    err := json.Unmarshal(input, &temp)
    if err != nil {
    	return err
    }
    err = temp.validate()
    if err != nil {
    	return err
    }
    additionalProperties, err := UnmarshalAdditionalProperties(input, "payment_profile")
    if err != nil {
    	return err
    }
    
    b.AdditionalProperties = additionalProperties
    b.PaymentProfile = *temp.PaymentProfile
    return nil
}

// tempBankAccountResponse is a temporary struct used for validating the fields of BankAccountResponse.
type tempBankAccountResponse  struct {
    PaymentProfile *BankAccountPaymentProfile `json:"payment_profile"`
}

func (b *tempBankAccountResponse) validate() error {
    var errs []string
    if b.PaymentProfile == nil {
        errs = append(errs, "required field `payment_profile` is missing for type `Bank Account Response`")
    }
    if len(errs) == 0 {
        return nil
    }
    return errors.New(strings.Join (errs, "\n"))
}
