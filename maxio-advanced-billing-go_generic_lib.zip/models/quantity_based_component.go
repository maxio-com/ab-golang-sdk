// Package advancedbilling
// This file was automatically generated for Maxio by APIMATIC v3.0 ( https://www.apimatic.io ).
package models

import (
    "encoding/json"
    "errors"
    "fmt"
    "strings"
)

// QuantityBasedComponent represents a QuantityBasedComponent struct.
type QuantityBasedComponent struct {
    // A name for this component that is suitable for showing customers and displaying on billing statements, e.g., "Minutes".
    Name                      string                           `json:"name"`
    // “The name of the unit of measurement for the component. It should be singular since it will be automatically pluralized when necessary. e.g., “message”, which may then be shown as “5 messages” on a subscription’s component line-item.”
    UnitName                  string                           `json:"unit_name"`
    // A description for the component that will be displayed to the user on the hosted signup page.
    Description               *string                          `json:"description,omitempty"`
    // A unique identifier for your use that can be used to retrieve this component in subsequent requests. Must start with a letter or number and may only contain lowercase letters, numbers, or the characters '.', ':', '-', or '_'.
    Handle                    *string                          `json:"handle,omitempty"`
    // Boolean flag describing whether a component is taxable or not.
    Taxable                   *bool                            `json:"taxable,omitempty"`
    // The identifier for the pricing scheme. See [Product Components](https://help.chargify.com/products/product-components.html) for an overview of pricing schemes.
    PricingScheme             PricingScheme                    `json:"pricing_scheme"`
    // (Not required for ‘per_unit’ pricing schemes) One or more price brackets. See [Price Bracket Rules](https://maxio.zendesk.com/hc/en-us/articles/24261149166733-Component-Pricing-Schemes#price-bracket-rules) for an overview of how price brackets work for different pricing schemes.
    Prices                    []Price                          `json:"prices,omitempty"`
    // The type of credit to be created when upgrading/downgrading. Defaults to the component and then site setting if one is not provided.
    UpgradeCharge             Optional[CreditType]             `json:"upgrade_charge"`
    // The type of credit to be created when upgrading/downgrading. Defaults to the component and then site setting if one is not provided.
    DowngradeCredit           Optional[CreditType]             `json:"downgrade_credit"`
    PricePoints               []ComponentPricePointItem        `json:"price_points,omitempty"`
    // The amount the customer will be charged per unit when the pricing scheme is “per_unit”. For On/Off Components, this is the amount that the customer will be charged when they turn the component on for the subscription. The price can contain up to 8 decimal places. e.g., 1.00 or 0.0012 or 0.00000065
    UnitPrice                 *QuantityBasedComponentUnitPrice `json:"unit_price,omitempty"`
    // A string representing the tax code related to the component type. This is especially important when using AvaTax to tax based on locale. This attribute has a max length of 25 characters.
    TaxCode                   *string                          `json:"tax_code,omitempty"`
    // (Only available on Relationship Invoicing sites) Boolean flag describing if the service date range should show for the component on generated invoices.
    HideDateRangeOnInvoice    *bool                            `json:"hide_date_range_on_invoice,omitempty"`
    Recurring                 *bool                            `json:"recurring,omitempty"`
    DisplayOnHostedPage       *bool                            `json:"display_on_hosted_page,omitempty"`
    AllowFractionalQuantities *bool                            `json:"allow_fractional_quantities,omitempty"`
    PublicSignupPageIds       []int                            `json:"public_signup_page_ids,omitempty"`
    // The numerical interval. e.g., an interval of ‘30’ coupled with an interval_unit of day would mean this component’s default price point would renew every 30 days. This property is only available for sites with Multifrequency enabled.
    Interval                  *int                             `json:"interval,omitempty"`
    // A string representing the interval unit for this component's default price point, either month or day. This property is only available for sites with Multifrequency enabled.
    IntervalUnit              Optional[IntervalUnit]           `json:"interval_unit"`
    // (Optional) Custom UNSPSC commodity code for Level 3/CEDP payment data. When set, this value is sent as the commodity code on invoice line items for this component instead of the default derived from item_category.
    UnspscCode                Optional[string]                 `json:"unspsc_code"`
    AdditionalProperties      map[string]interface{}           `json:"_"`
}

// String implements the fmt.Stringer interface for QuantityBasedComponent,
// providing a human-readable string representation useful for logging, debugging or displaying information.
func (q QuantityBasedComponent) String() string {
    return fmt.Sprintf(
    	"QuantityBasedComponent[Name=%v, UnitName=%v, Description=%v, Handle=%v, Taxable=%v, PricingScheme=%v, Prices=%v, UpgradeCharge=%v, DowngradeCredit=%v, PricePoints=%v, UnitPrice=%v, TaxCode=%v, HideDateRangeOnInvoice=%v, Recurring=%v, DisplayOnHostedPage=%v, AllowFractionalQuantities=%v, PublicSignupPageIds=%v, Interval=%v, IntervalUnit=%v, UnspscCode=%v, AdditionalProperties=%v]",
    	q.Name, q.UnitName, q.Description, q.Handle, q.Taxable, q.PricingScheme, q.Prices, q.UpgradeCharge, q.DowngradeCredit, q.PricePoints, q.UnitPrice, q.TaxCode, q.HideDateRangeOnInvoice, q.Recurring, q.DisplayOnHostedPage, q.AllowFractionalQuantities, q.PublicSignupPageIds, q.Interval, q.IntervalUnit, q.UnspscCode, q.AdditionalProperties)
}

// MarshalJSON implements the json.Marshaler interface for QuantityBasedComponent.
// It customizes the JSON marshaling process for QuantityBasedComponent objects.
func (q QuantityBasedComponent) MarshalJSON() (
    []byte,
    error) {
    if err := DetectConflictingProperties(q.AdditionalProperties,
        "name", "unit_name", "description", "handle", "taxable", "pricing_scheme", "prices", "upgrade_charge", "downgrade_credit", "price_points", "unit_price", "tax_code", "hide_date_range_on_invoice", "recurring", "display_on_hosted_page", "allow_fractional_quantities", "public_signup_page_ids", "interval", "interval_unit", "unspsc_code"); err != nil {
        return []byte{}, err
    }
    return json.Marshal(q.toMap())
}

// toMap converts the QuantityBasedComponent object to a map representation for JSON marshaling.
func (q QuantityBasedComponent) toMap() map[string]any {
    structMap := make(map[string]any)
    MergeAdditionalProperties(structMap, q.AdditionalProperties)
    structMap["name"] = q.Name
    structMap["unit_name"] = q.UnitName
    if q.Description != nil {
        structMap["description"] = q.Description
    }
    if q.Handle != nil {
        structMap["handle"] = q.Handle
    }
    if q.Taxable != nil {
        structMap["taxable"] = q.Taxable
    }
    structMap["pricing_scheme"] = q.PricingScheme
    if q.Prices != nil {
        structMap["prices"] = q.Prices
    }
    if q.UpgradeCharge.IsValueSet() {
        if q.UpgradeCharge.Value() != nil {
            structMap["upgrade_charge"] = q.UpgradeCharge.Value()
        } else {
            structMap["upgrade_charge"] = nil
        }
    }
    if q.DowngradeCredit.IsValueSet() {
        if q.DowngradeCredit.Value() != nil {
            structMap["downgrade_credit"] = q.DowngradeCredit.Value()
        } else {
            structMap["downgrade_credit"] = nil
        }
    }
    if q.PricePoints != nil {
        structMap["price_points"] = q.PricePoints
    }
    if q.UnitPrice != nil {
        structMap["unit_price"] = q.UnitPrice.toMap()
    }
    if q.TaxCode != nil {
        structMap["tax_code"] = q.TaxCode
    }
    if q.HideDateRangeOnInvoice != nil {
        structMap["hide_date_range_on_invoice"] = q.HideDateRangeOnInvoice
    }
    if q.Recurring != nil {
        structMap["recurring"] = q.Recurring
    }
    if q.DisplayOnHostedPage != nil {
        structMap["display_on_hosted_page"] = q.DisplayOnHostedPage
    }
    if q.AllowFractionalQuantities != nil {
        structMap["allow_fractional_quantities"] = q.AllowFractionalQuantities
    }
    if q.PublicSignupPageIds != nil {
        structMap["public_signup_page_ids"] = q.PublicSignupPageIds
    }
    if q.Interval != nil {
        structMap["interval"] = q.Interval
    }
    if q.IntervalUnit.IsValueSet() {
        if q.IntervalUnit.Value() != nil {
            structMap["interval_unit"] = q.IntervalUnit.Value()
        } else {
            structMap["interval_unit"] = nil
        }
    }
    if q.UnspscCode.IsValueSet() {
        if q.UnspscCode.Value() != nil {
            structMap["unspsc_code"] = q.UnspscCode.Value()
        } else {
            structMap["unspsc_code"] = nil
        }
    }
    return structMap
}

// UnmarshalJSON implements the json.Unmarshaler interface for QuantityBasedComponent.
// It customizes the JSON unmarshaling process for QuantityBasedComponent objects.
func (q *QuantityBasedComponent) UnmarshalJSON(input []byte) error {
    var temp tempQuantityBasedComponent
    err := json.Unmarshal(input, &temp)
    if err != nil {
    	return err
    }
    err = temp.validate()
    if err != nil {
    	return err
    }
    additionalProperties, err := ExtractAdditionalProperties[interface{}](input, "name", "unit_name", "description", "handle", "taxable", "pricing_scheme", "prices", "upgrade_charge", "downgrade_credit", "price_points", "unit_price", "tax_code", "hide_date_range_on_invoice", "recurring", "display_on_hosted_page", "allow_fractional_quantities", "public_signup_page_ids", "interval", "interval_unit", "unspsc_code")
    if err != nil {
    	return err
    }
    q.AdditionalProperties = additionalProperties
    
    q.Name = *temp.Name
    q.UnitName = *temp.UnitName
    q.Description = temp.Description
    q.Handle = temp.Handle
    q.Taxable = temp.Taxable
    q.PricingScheme = *temp.PricingScheme
    q.Prices = temp.Prices
    q.UpgradeCharge = temp.UpgradeCharge
    q.DowngradeCredit = temp.DowngradeCredit
    q.PricePoints = temp.PricePoints
    q.UnitPrice = temp.UnitPrice
    q.TaxCode = temp.TaxCode
    q.HideDateRangeOnInvoice = temp.HideDateRangeOnInvoice
    q.Recurring = temp.Recurring
    q.DisplayOnHostedPage = temp.DisplayOnHostedPage
    q.AllowFractionalQuantities = temp.AllowFractionalQuantities
    q.PublicSignupPageIds = temp.PublicSignupPageIds
    q.Interval = temp.Interval
    q.IntervalUnit = temp.IntervalUnit
    q.UnspscCode = temp.UnspscCode
    return nil
}

// tempQuantityBasedComponent is a temporary struct used for validating the fields of QuantityBasedComponent.
type tempQuantityBasedComponent  struct {
    Name                      *string                          `json:"name"`
    UnitName                  *string                          `json:"unit_name"`
    Description               *string                          `json:"description,omitempty"`
    Handle                    *string                          `json:"handle,omitempty"`
    Taxable                   *bool                            `json:"taxable,omitempty"`
    PricingScheme             *PricingScheme                   `json:"pricing_scheme"`
    Prices                    []Price                          `json:"prices,omitempty"`
    UpgradeCharge             Optional[CreditType]             `json:"upgrade_charge"`
    DowngradeCredit           Optional[CreditType]             `json:"downgrade_credit"`
    PricePoints               []ComponentPricePointItem        `json:"price_points,omitempty"`
    UnitPrice                 *QuantityBasedComponentUnitPrice `json:"unit_price,omitempty"`
    TaxCode                   *string                          `json:"tax_code,omitempty"`
    HideDateRangeOnInvoice    *bool                            `json:"hide_date_range_on_invoice,omitempty"`
    Recurring                 *bool                            `json:"recurring,omitempty"`
    DisplayOnHostedPage       *bool                            `json:"display_on_hosted_page,omitempty"`
    AllowFractionalQuantities *bool                            `json:"allow_fractional_quantities,omitempty"`
    PublicSignupPageIds       []int                            `json:"public_signup_page_ids,omitempty"`
    Interval                  *int                             `json:"interval,omitempty"`
    IntervalUnit              Optional[IntervalUnit]           `json:"interval_unit"`
    UnspscCode                Optional[string]                 `json:"unspsc_code"`
}

func (q *tempQuantityBasedComponent) validate() error {
    var errs []string
    if q.Name == nil {
        errs = append(errs, "required field `name` is missing for type `Quantity Based Component`")
    }
    if q.UnitName == nil {
        errs = append(errs, "required field `unit_name` is missing for type `Quantity Based Component`")
    }
    if q.PricingScheme == nil {
        errs = append(errs, "required field `pricing_scheme` is missing for type `Quantity Based Component`")
    }
    if len(errs) == 0 {
        return nil
    }
    return errors.New(strings.Join (errs, "\n"))
}
