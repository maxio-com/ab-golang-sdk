// Package advancedbilling
// This file was automatically generated for Maxio by APIMATIC v3.0 ( https://www.apimatic.io ).
package models

import (
    "encoding/json"
    "fmt"
    "log"
    "time"
)

// ProductFamily represents a ProductFamily struct.
type ProductFamily struct {
    Id                   *int                   `json:"id,omitempty"`
    Name                 *string                `json:"name,omitempty"`
    Handle               *string                `json:"handle,omitempty"`
    AccountingCode       Optional[string]       `json:"accounting_code"`
    Description          Optional[string]       `json:"description"`
    // Whether surcharging applies to this product family. Only included on sites where surcharging is enabled.
    Surcharging          *bool                  `json:"surcharging,omitempty"`
    CreatedAt            *time.Time             `json:"created_at,omitempty"`
    UpdatedAt            *time.Time             `json:"updated_at,omitempty"`
    // Timestamp indicating when this product family was archived. `null` if the product family is not archived.
    ArchivedAt           Optional[time.Time]    `json:"archived_at"`
    AdditionalProperties map[string]interface{} `json:"_"`
}

// String implements the fmt.Stringer interface for ProductFamily,
// providing a human-readable string representation useful for logging, debugging or displaying information.
func (p ProductFamily) String() string {
    return fmt.Sprintf(
    	"ProductFamily[Id=%v, Name=%v, Handle=%v, AccountingCode=%v, Description=%v, Surcharging=%v, CreatedAt=%v, UpdatedAt=%v, ArchivedAt=%v, AdditionalProperties=%v]",
    	p.Id, p.Name, p.Handle, p.AccountingCode, p.Description, p.Surcharging, p.CreatedAt, p.UpdatedAt, p.ArchivedAt, p.AdditionalProperties)
}

// MarshalJSON implements the json.Marshaler interface for ProductFamily.
// It customizes the JSON marshaling process for ProductFamily objects.
func (p ProductFamily) MarshalJSON() (
    []byte,
    error) {
    if err := DetectConflictingProperties(p.AdditionalProperties,
        "id", "name", "handle", "accounting_code", "description", "surcharging", "created_at", "updated_at", "archived_at"); err != nil {
        return []byte{}, err
    }
    return json.Marshal(p.toMap())
}

// toMap converts the ProductFamily object to a map representation for JSON marshaling.
func (p ProductFamily) toMap() map[string]any {
    structMap := make(map[string]any)
    MergeAdditionalProperties(structMap, p.AdditionalProperties)
    if p.Id != nil {
        structMap["id"] = p.Id
    }
    if p.Name != nil {
        structMap["name"] = p.Name
    }
    if p.Handle != nil {
        structMap["handle"] = p.Handle
    }
    if p.AccountingCode.IsValueSet() {
        if p.AccountingCode.Value() != nil {
            structMap["accounting_code"] = p.AccountingCode.Value()
        } else {
            structMap["accounting_code"] = nil
        }
    }
    if p.Description.IsValueSet() {
        if p.Description.Value() != nil {
            structMap["description"] = p.Description.Value()
        } else {
            structMap["description"] = nil
        }
    }
    if p.Surcharging != nil {
        structMap["surcharging"] = p.Surcharging
    }
    if p.CreatedAt != nil {
        structMap["created_at"] = p.CreatedAt.Format(time.RFC3339)
    }
    if p.UpdatedAt != nil {
        structMap["updated_at"] = p.UpdatedAt.Format(time.RFC3339)
    }
    if p.ArchivedAt.IsValueSet() {
        var ArchivedAtVal *string = nil
        if p.ArchivedAt.Value() != nil {
            val := p.ArchivedAt.Value().Format(time.RFC3339)
            ArchivedAtVal = &val
        }
        if p.ArchivedAt.Value() != nil {
            structMap["archived_at"] = ArchivedAtVal
        } else {
            structMap["archived_at"] = nil
        }
    }
    return structMap
}

// UnmarshalJSON implements the json.Unmarshaler interface for ProductFamily.
// It customizes the JSON unmarshaling process for ProductFamily objects.
func (p *ProductFamily) UnmarshalJSON(input []byte) error {
    var temp tempProductFamily
    err := json.Unmarshal(input, &temp)
    if err != nil {
    	return err
    }
    additionalProperties, err := ExtractAdditionalProperties[interface{}](input, "id", "name", "handle", "accounting_code", "description", "surcharging", "created_at", "updated_at", "archived_at")
    if err != nil {
    	return err
    }
    p.AdditionalProperties = additionalProperties
    
    p.Id = temp.Id
    p.Name = temp.Name
    p.Handle = temp.Handle
    p.AccountingCode = temp.AccountingCode
    p.Description = temp.Description
    p.Surcharging = temp.Surcharging
    if temp.CreatedAt != nil {
        CreatedAtVal, err := time.Parse(time.RFC3339, *temp.CreatedAt)
        if err != nil {
            log.Fatalf("Cannot Parse created_at as % s format.", time.RFC3339)
        }
        p.CreatedAt = &CreatedAtVal
    }
    if temp.UpdatedAt != nil {
        UpdatedAtVal, err := time.Parse(time.RFC3339, *temp.UpdatedAt)
        if err != nil {
            log.Fatalf("Cannot Parse updated_at as % s format.", time.RFC3339)
        }
        p.UpdatedAt = &UpdatedAtVal
    }
    p.ArchivedAt.ShouldSetValue(temp.ArchivedAt.IsValueSet())
    if temp.ArchivedAt.Value() != nil {
        ArchivedAtVal, err := time.Parse(time.RFC3339, (*temp.ArchivedAt.Value()))
        if err != nil {
            log.Fatalf("Cannot Parse archived_at as % s format.", time.RFC3339)
        }
        p.ArchivedAt.SetValue(&ArchivedAtVal)
    }
    return nil
}

// tempProductFamily is a temporary struct used for validating the fields of ProductFamily.
type tempProductFamily  struct {
    Id             *int             `json:"id,omitempty"`
    Name           *string          `json:"name,omitempty"`
    Handle         *string          `json:"handle,omitempty"`
    AccountingCode Optional[string] `json:"accounting_code"`
    Description    Optional[string] `json:"description"`
    Surcharging    *bool            `json:"surcharging,omitempty"`
    CreatedAt      *string          `json:"created_at,omitempty"`
    UpdatedAt      *string          `json:"updated_at,omitempty"`
    ArchivedAt     Optional[string] `json:"archived_at"`
}
